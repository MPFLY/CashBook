const handle = require('./handle');

exports.login = (req, res) => {
	handle.Login(req.body.username, (data) => {

		if(!data[0]) {
			res.json({
				"code": 404,
				"msg": "查无此人"
			})
		} else if(req.body.password === data[0].password) { // 登陆成功
			res.json({
				"code": 200,
				"username": data[0].username,
				"uid": data[0].uid,
				"password": data[0].password,
				"msg": "登陆成功"
			})
		} else {
			res.json({
				"code": 400,
				"msg": "密码错误"
			})
		}
	});
};
exports.query = (req, res) => {
	let param = req.body;
	handle.Query(param,(data) => {
		res.json(data);
	});
};
exports.delete = (req, res) => {
	let id = req.body.id;
	handle.Delete(id, (data) => {
		res.json(data);
	});
};
exports.dimSearch = (req, res) => {
	let word = req.body.word;
	handle.DimSearch(word, (data) => {
		res.json(data);
	});
};
exports.add = (req, res) => {
	let param = req.body;
	handle.Add(param, (data) => {

	});
};
exports.edit = (req, res) => {
	let param = req.body;
	handle.Edit(param, () => {
	});
};
exports.updateById = (req, res) => {
	let param = req.body;
	handle.updateById(param, (data) => {
		res.json(data);
	})
};
exports.ajax = (req, res) => {
	let param = req.body;
	console.log(param.username);
	res.json({"res":"成功！"});
};
exports.queryBook = (req, res) => {
	let param = req.body;
	handle.queryBook(param, (data) => {
		res.json(data);
	})
};
exports.addBook = (req, res) => {
	let param = req.body;
	handle.addBook(param, (data) => {
		res.json(data);
	})
};
exports.delBook = (req, res) => {
	let param = req.body;
	handle.delBook(param, (data) => {
		res.json(data);
	})
};
exports.queryBookByUid = (req, res) => {
	let param = req.body;
	handle.queryBookByUid(param, (data) => {
		res.json(data);
	})
};
exports.delCountByBid = (req, res) => {
	let param = req.body;
	handle.delCountByBid(param, (data) => {
		res.json(data);
	})
};
exports.queryType = (req, res) => {
	let param = req.body;
	handle.queryType(param, (data) => {
		res.json(data);
	})
};
exports.queryTypeByTid = (req, res) => {
	let param = req.body;
	handle.queryTypeByTid(param, (data) => {
		res.json(data);
	})
};
exports.addType = (req, res) => {
	let param = req.body;
	handle.addType(param, (data) => {
		res.json(data);
	})
};
exports.delType = (req, res) => {
	let param = req.body;
	handle.delType(param, (data) => {
		res.json(data);
	})
};
exports.updateType = (req, res) => {
	let param = req.body;
	handle.updateType(param, (data) => {
		res.json(data);
	})
};
exports.delTidFromCount_info = (req, res) => {
	let param = req.body;
	handle.delTidFromCount_info(param, (data) => {
		res.json(data);
	})
};

exports.queryFund = (req, res) => {
	let param = req.body;
	handle.queryFund(param, (data) => {
		res.json(data);
	})
};

exports.addFund = (req, res) => {
	let param = req.body;
	handle.addFund(param, (data) => {
		res.json(data);
	})
};
exports.queryCountByFid = (req, res) => {
	let param = req.body;
	handle.queryCountByFid(param, (data) => {
		res.json(data);
	})
};
exports.editFund = (req, res) => {
	let param = req.body;
	handle.editFund(param, (data) => {
		res.json(data);
	})
};


