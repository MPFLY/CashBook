const express = require('express');
const router = express.Router();
const route = require('./api-routers');
const uploads = require('./api-upload');
// 登录
router.post('/login.do', route.login);
// 查找所有
router.post('/findAll.do',route.query);
// 删除数据
router.post('/delete.do', route.delete);
// 模糊查找
router.post('/dimSearch.do', route.dimSearch);
// 新增
router.post('/add.do', route.add);
// 编辑
router.post('/edit.do', route.edit);
//通过id修改信息
router.post('/updateById.do', route.updateById);
router.post('/ajax.do', route.ajax);
//查询某个用户的全部账本
router.post('/queryBook.do', route.queryBook);
//为某个用户添加一个账本
router.post('/addBook.do', route.addBook);
//删除账本
router.post('/delBook.do', route.delBook);

//通过用户id拿到属于该用户的账本
router.post('/queryBookByUid.do', route.queryBookByUid);
//通过账本id删除属于该账本下的所有账单
router.post('/delCountByBid.do', route.delCountByBid);

//在初始化时拿到所有的支出类型
router.post('/queryType.do', route.queryType);
//根据tid查找type
router.post('/queryTypeByTid.do', route.queryTypeByTid);
//添加类型
router.post('/addType.do', route.addType);
//删除类型
router.post('/delType.do', route.delType);
//修改类型
router.post('/updateType.do', route.updateType);
//删除count_info中的tid
router.post('/delTidFromCount_info.do', route.delTidFromCount_info);
//查询所有资金
router.post('/queryFund.do', route.queryFund);
//添加资金类型
router.post('/addFund.do', route.addFund);
//据资金类型查询count
router.post('/queryCountByFid.do', route.queryCountByFid);
//编辑资金账户
router.post('/editFund.do', route.editFund);
module.exports = router; 
