const db = require('./db');
/**
 * 登录
 */
//Conunt_User
exports.Login = (username, callback) => {
	let sql = 'select * from Conunt_User where username="' + username + '"';
	db.query(sql, callback);
};
/**
 * 初始化显示name,age,tel,email
 * */
exports.Query = function(param,callback) {
	let sql = 'select * from count_info where bid = ?';
	let sqlArr = [param.bid];
	db.queryParam(sql, sqlArr, callback);
};
/**
 * 通过id删除
 * */
exports.Delete = (id, callback) => {
	let sql = 'delete from count_info where cid=' + id;
	db.query(sql, callback);
};
/**
 * 输入框模糊查询
 */
exports.DimSearch = (word, callback) => {
	let sql = "select * from count_info where pay like '%" + word + "%' or date like '%" + word + "%' or note like '%" + word + "%'";
	db.query(sql, callback);
}

/**
 * 增加操作
 * */
exports.Add = (param, callback) => {
	let sql = 'insert into count_info (pay,date,note,tid,bid,fid) values (?,?,?,?,?,?)';
	let sqlArr = [param.pay+'元', param.date, param.note,param.tid,param.bid,param.fid];
	db.queryParam(sql, sqlArr, callback);
};
/**
 * 更新操作
 * */
exports.Edit = (param, callback) => {
	let sql = 'update count_info set pay=?,date=?,note=?,tid=? where cid=?';
	let sqlArr = [param.pay, param.date, param.note,param.tid,param.cid];
	db.queryParam(sql, sqlArr, callback);
};

//通过id修改信息
exports.updateById = (param, callback) => {
	let sql = 'update conunt_user set username=?,password=? where uid=?';
	let sqlArr = [param.username, param.password,param.uid];
	db.queryParam(sql, sqlArr, callback);
};

exports.queryBook = (param, callback) => {
	let sql = 'select * from count_book where uid=?';
	let sqlArr = [param.uid];
	db.queryParam(sql, sqlArr, callback);
};
exports.addBook = (param, callback) => {
	let sql = 'insert into count_book (bookName,uid) values (?,?)';
	let sqlArr = [param.bookName,param.uid];
	db.queryParam(sql, sqlArr, callback);
};
exports.delBook = (param, callback) => {
	let sql = 'delete from count_book where bid = ?';
	let sqlArr = [param.bid];
	db.queryParam(sql, sqlArr, callback);
};
exports.queryBookByUid = (param, callback) => {
	let sql = 'select * from count_book where uid = ?';
	let sqlArr = [param.uid];
	db.queryParam(sql, sqlArr, callback);
};
exports.delCountByBid = (param, callback) => {
	let sql = 'delete from count_info where bid = ?';
	let sqlArr = [param.bid];
	db.queryParam(sql, sqlArr, callback);
};
exports.queryType = (param, callback) => {
	let sql = 'select * from count_type';
	db.queryParam(sql, '',callback);
};
exports.queryTypeByTid = (param, callback) => {
	let sql = 'select * from count_type where tid = ?';
	let sqlArr = [param.tid];
	db.queryParam(sql,sqlArr,callback);
};
exports.addType = (param, callback) => {
	let sql = 'insert into count_type (type) values (?)';
	let sqlArr = [param.type];
	db.queryParam(sql,sqlArr,callback);
};
exports.delType = (param, callback) => {
	let sql = 'delete from count_type where tid = ?';
	let sqlArr = [param.tid];
	db.queryParam(sql,sqlArr,callback);
};

exports.updateType = (param, callback) => {
	let sql = 'update count_type set type=? where tid = ?';
	let sqlArr = [param.type,param.tid];
	db.queryParam(sql,sqlArr,callback);
};
exports.delTidFromCount_info = (param, callback) => {
	let sql = 'update count_info set tid = null where tid = ?';
	let sqlArr = [param.tid];
	db.queryParam(sql,sqlArr,callback);
};
exports.queryFund = (param, callback) => {
	let sql = 'select * from count_fund';
//	let sqlArr = [param.tid];
	db.queryParam(sql,'',callback);
};

exports.addFund = (param, callback) => {
	let sql = 'insert into count_fund (fund) values (?)';
	let sqlArr = [param.fund];
	db.queryParam(sql,sqlArr,callback);
};

exports.queryCountByFid = (param, callback) => {
	let sql = 'select * from count_info where fid = ?';
	let sqlArr = [param.fid];
	db.queryParam(sql,sqlArr,callback);
};
exports.editFund = (param, callback) => {
	let sql = 'update count_fund set fund=?,balance=? where fid = ?';
	let sqlArr = [param.fund,param.balance,param.fid];
	db.queryParam(sql,sqlArr,callback);
};

