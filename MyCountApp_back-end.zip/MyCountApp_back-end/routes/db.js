var mysql = require('mysql');
var pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'mycount'
});
console.log('数据库连接成功')
function _query(sql, callback) {
    pool.getConnection(function (err, connection) {
        // Use the connection
        connection.query(sql, function (err, rows) {
            callback(rows);
            connection.release();//释放链接
        });
    });
}
function queryParam(sql,param, callback) {
    pool.getConnection(function (err, connection) {
        // Use the connection
        connection.query(sql,param, function (err, rows) {
            if(err)console.log(err);
            callback(rows);
            connection.release();//释放链接
        });
    });
}
exports.query = _query;
exports.queryParam = queryParam;