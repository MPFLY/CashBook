const fs = require('fs');
const formidable = require("formidable");

exports.upload = (req,res)=>{
    let form = new formidable.IncomingForm();
    form.uploadDir = "./public/upload/temp/"; //改变临时目录
    form.keepExtensions = true;
    form.parse(req, function(error, fields, files) {
        if(files.file.type.indexOf('image')!==-1){   //如果是图片
            let fName = (new Date()).getTime();
            let suffix = files.file.name.split('.').pop();
            let uploadDir = "./public/upload/" + fName + "." + suffix;
            fs.rename(files.file.path, uploadDir, function(err) {
                if (err) {
                    console.log("重命名失败：" + err);
                }else{
                    console.log("上传成功",fName);
                    res.json({
                        'path': uploadDir
                    })
                }
            })
        }
    });
}