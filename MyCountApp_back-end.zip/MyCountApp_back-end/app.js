var express = require('express');
var bodyParser = require('body-parser');
var app = express();

app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());

app.use('/pnode',express.static('./public'));

app.use('/pnode',require('./routes/api'));





var port = 8089;
app.listen(port);