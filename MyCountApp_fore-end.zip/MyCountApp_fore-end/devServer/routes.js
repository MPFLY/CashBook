var path = require('path');
var util = require('util');
var fs = require('fs');
var proxyMiddleware = require('http-proxy-middleware');
var proxyConfig = require('./proxy');
var proxyTable = proxyConfig.proxyTable;
var appPath = path.resolve(__dirname,'../static');
var jsonPath = path.join(appPath, 'data');

module.exports = function (app) {

	if (proxyConfig.enable) {/*启用代理功能*/
		Object.keys(proxyTable).forEach(function (context) {
			var options = proxyTable[context];
			if (typeof options === 'string') {
				options = {target: options}
			}
			options.logLevel = options.logLevel || 'debug';
			app.use(proxyMiddleware(options.filter || context, options));
		});
	}
	if (proxyConfig.enableLocal) {
		app.use(proxyLocalJson());
	}
};

function proxyLocalJson(options) {
	return function (req, res, next) {
		var url = req.url;
		if (/^\/local/.test(url)) {
			var localJson = url.replace(/\/local\/(.*?)\.do(\?.*)?$/, '$1.json');
			console.log('proxyLocalJson:' + url + '===>' + localJson);
			fs.readFile(path.join(jsonPath, localJson), 'utf-8', function (err, result) {
				if (err) {
					console.log(err);
					res.status(404).end();
				} else {
					res.send(result);
				}
			});
		} else {
			next();
		}
	}
}