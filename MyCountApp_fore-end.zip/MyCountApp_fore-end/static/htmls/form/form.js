formCtrl.$inject = ['$scope', '$remote', "$timeout", "$filter", "$rootScope",
	"$chartService"
];

function formCtrl($scope, $remote, $timeout, $filter, $rootScope, $chartService) {
	$rootScope.flag = 2;
	$rootScope.showBottom = true;
	$scope.startup = function() {
		//折线图的数据
		var AllData = [];
		for(var i=0;i<$rootScope.datas.length;i++){
			AllData.push({"date": $rootScope.datas[i].date,
			"number":parseInt($rootScope.datas[i].pay)})
		}
		$chartService.line(document.getElementById("canvas"),AllData);
		
		
		
		// 获得环形图数据，并初始化
				
		$chartService.doughnut(document.getElementById("canvasId"), {
			
            "usedAmount1":100,
            "usedAmount2":200,
            "usedAmount3":300,
            "usedAmount4":400,
            "usedAmount5":500,
            "usedAmount6":0,
            
            "useLabel1":"交通",
            "useLabel2":"居住",
            "useLabel3":"娱乐",
            "useLabel4":"餐饮",
            "useLabel5":"购物",
            "useLabel6":"医疗"
        });
	}
};