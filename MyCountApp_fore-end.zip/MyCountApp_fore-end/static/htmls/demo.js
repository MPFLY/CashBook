demoCtrl.$inject = ["$scope", "$remote", "$rootScope", "$modal"];

function demoCtrl($scope, $remote, $rootScope, $modal) {

	$rootScope.showBottom = false;
	//添加类型
	$scope.addType = function(url) {
		window.event ? window.event.cancelBubble = true : e.stopPropagation();
		var modalInstance = $modal.open({
			templateUrl: url,
			controller: addTypeModalInstanceCtrl
		});
		addTypeModalInstanceCtrl.$inject = ['$scope', '$modalInstance'];

		function addTypeModalInstanceCtrl($scope, $modalInstance) {
			$scope.ok = function() {
				var type = $scope.type;
				if(type == null){
					
				}else{
					$remote.post('addType.do', {
						'type': type
					}, function(data) {
						//重新获取数据
						$remote.post('queryType.do', {}, function(data) {
							$rootScope.types = data;
						});
					});
					$modalInstance.close();
				};
			};
			$scope.cancel = function() {
				$modalInstance.close();
			};
		};
	};
	//	删除支出类型
	//因为与账单信息有外键关联，所以要想删除某一个‘支出类型’，需要先把使用该‘类型’的账单中的该类型删除掉
	$scope.delType = function(tid, url) {
		window.event ? window.event.cancelBubble = true : e.stopPropagation();
		var modalInstance = $modal.open({
			templateUrl: url,
			controller: delTypeModalInstanceCtrl
		});
		delTypeModalInstanceCtrl.$inject = ['$scope', '$modalInstance'];

		function delTypeModalInstanceCtrl($scope, $modalInstance) {
			$scope.ok = function() {
				//删除count_info中的tid字段，不论是否使用该字段，都删除掉。
				$remote.post('delTidFromCount_info.do', {
					'tid': tid
				}, function(data) {
					//删除count_type表中的type
					$remote.post('delType.do', {
						'tid': tid
					}, function(data) {
						//重新获取数据
						$remote.post('queryType.do', {}, function(data) {
							$rootScope.types = data;
						});
					});
				});
				$modalInstance.close();
			};
			$scope.cancel = function() {
				$modalInstance.close();
			};
		};
	};

	//修改类型
	$scope.updateType = function(item, url) {
		window.event ? window.event.cancelBubble = true : e.stopPropagation();
		var modalInstance = $modal.open({
			templateUrl: url,
			controller: updateTypeModalInstanceCtrl
		});
		updateTypeModalInstanceCtrl.$inject = ['$scope', '$modalInstance'];

		function updateTypeModalInstanceCtrl($scope, $modalInstance) {
			$scope.upType = item.type;

			$scope.ok = function() {
				if($scope.upType == null) {

				} else {
					var param = {
						'tid': item.tid,
						'type': $scope.upType
					}
					console.log(param.tid + "/" + param.type);
					$remote.post('updateType.do', param, function(data) {
						//重新获取数据
						$remote.post('queryType.do', {}, function(data) {
							$rootScope.types = data;
						});
					});
					$modalInstance.close();
				};

			};
			$scope.cancel = function() {
				$modalInstance.close();
			};
		};
	};
}