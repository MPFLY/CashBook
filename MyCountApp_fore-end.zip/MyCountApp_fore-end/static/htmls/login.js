LoginCtrl.$inject = ["$scope", "$remote", "$rootScope"];

function LoginCtrl($scope, $remote, $rootScope) {
	$scope.errInfo = ""
	$scope.doLogin = function() {
		var param = {
			'username': $scope.username,
			'password': $scope.password
		}
		$.ajax({
			data: param,
			url: '/pnode/login.do',
			type: 'post',
			dataType: 'json',
			success: function(data) {
				switch(data.code) {
					case 404:
						$scope.$apply(function() {
							$scope.errInfo = "用户名或密码错误";
						});
						break;
					case 400:
						$scope.$apply(function() {
							$scope.errInfo = "用户名或密码错误";
						});
						break;
					case 200:
						var userinfo = {
							'username': $scope.username,
							'uname': data.username,
							'uid': data.uid,
							"password": data.password
						}

						sessionStorage.setItem('userinfo', JSON.stringify(userinfo));
						$scope.goto('index');
						break;
					default:
						$scope.$apply(function() {
							$scope.errInfo = "未知错误";
						});
				};

			},

			error: function(jqXHR, textStatus, errorThrown) {
				alert('error ' + textStatus + " " + errorThrown);
			}
		});

	}
	
	
	//这是测试
	$scope.ajaxTest = function() {
		var params = {
			username: "mi",
			password: "asd123"
		};
		$.ajax({
			data: params,
			url: '/pnode/ajax.do',
			type: 'post',
			dataType: 'json',
			success: function(data) {
				$scope.$apply(function() {
					$scope.res = data.res;
				});
			},
			error: function(jqXHR, textStatus, errorThrown) {
				alert('error ' + textStatus + " " + errorThrown);
			}
		});
	};

}