fundCtrl.$inject = ['$scope', '$remote', "$timeout", "$filter", "$context", "$rootScope", "$modal"];

function fundCtrl($scope, $remote, $timeout, $filter, $context, $rootScope, $modal) {
	$rootScope.flag = 3;
	$rootScope.showBottom = true;
	
	
	//跳转到相应的资金类型的编辑页面
	$scope.getFund = function(item) {
		$scope.$context.setNextScope({
			item: item
		})
		$scope.goto("/cash");
	}

	$scope.addFund = function(url) {
		window.event ? window.event.cancelBubble = true : e.stopPropagation();
		var modalInstance = $modal.open({
			templateUrl: url,
			controller: addFundModalInstanceCtrl
		});
		addFundModalInstanceCtrl.$inject = ['$scope', '$modalInstance'];

		function addFundModalInstanceCtrl($scope, $modalInstance) {
			
			
			$scope.ok = function() {
				var fund = $scope.fund;
				if(fund == null) {

				} else {
					$remote.post('addFund.do', {
						'fund': fund
					}, function(data) {
						//重新获取数据
						$remote.post('queryFund.do', {}, function(data) {
							$rootScope.funds = data;
						});
					});
					$modalInstance.close();
				};
			};
			$scope.cancel = function() {
				$modalInstance.close();
			};
		};
	};

};