cashCtrl.$inject = ['$scope', '$remote', "$timeout", "$filter", "$rootScope","$modal"];

function cashCtrl($scope, $remote, $timeout, $filter, $rootScope,$modal) {
	$rootScope.showBottom = false;

	var item = $scope.item;
	//将该资金中所有的支出查询出来
	$scope.init = function() {
		$remote.post('queryCountByFid.do', {
			'fid': item.fid
		}, function(data) {
			$rootScope.counts = data;
		});
		console.log(item.fid);
	};

	$scope.editFund = function(url) {
		window.event ? window.event.cancelBubble = true : e.stopPropagation();
		var modalInstance = $modal.open({
			templateUrl: url,
			size: "lg",
			controller: editFundModalInstanceCtrl
		});

		editFundModalInstanceCtrl.$inject = ['$scope', '$modalInstance'];

		function editFundModalInstanceCtrl($scope, $modalInstance) {
			$scope. _fund = item.fund;
			$scope. _balance = parseInt(item.balance);
			
			
			$scope.ensure = function() {
					var param = {
						"fid":item.fid,
						"fund": $scope._fund,
						"balance": $scope._balance
					}
					$remote.post('e ditFund.do', param, function() {});
					//重新获取数据并关闭弹出框
//					$remote.post('findAll.do', {
//						'bid': $rootScope.bid
//					}, function(data) {
//						$rootScope.datas = data;
//						$scope.getPaySum(data);
//					});
					$scope.item = {'fund':$scope._fund,'balance':$scope._balance};
//					$scope.item.balance = $scope._balance;
					$modalInstance.close();
			};
			$scope.cancel = function() {
				$modalInstance.close();
			};
		};
	};

};