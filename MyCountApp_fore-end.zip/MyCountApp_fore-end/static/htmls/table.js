TableCtrl.$inject = ['$scope', '$remote', '$modal', '$rootScope'];

function TableCtrl($scope, $remote, $modal, $rootScope) {
	//拿到账单的总支出
	$rootScope.getPaySum = function(data) {
		var paySum = 0;
		for(var i = 0; i < data.length; i++) {
			paySum += parseInt(data[i].pay)
		};
		$rootScope.paySum = '总支出：' + paySum + '元';
	}

	$rootScope.bid;
	//初始化
	$scope.init = function() {
		$rootScope.showBottom = true;
		$rootScope.flag = 1;
		var username = $scope.showInfo.username;
		var password = $scope.showInfo.password;
		var uid = $scope.showInfo.uid;
		$rootScope.username = username;
		$rootScope.uid = uid;
		//显示列表
		//通过用户id拿到属于该用户的账本
		$remote.post('queryBookByUid.do', {
			'uid': uid
		}, function(data) {
			if(data.length == 0){
				alert("您还没有账本哦~~  先添加一个吧！");
			}else{
				$rootScope.bid = data[0].bid;
				$rootScope.bookName = data[0].bookName;
				$remote.post('findAll.do', {
					'bid': data[0].bid
				}, function(data) {
					if(data.length == 0){
						alert("该账本还没有数据哦~~");
//						$rootScope.havaData = true;
					}else{
						$rootScope.datas = data;
						$rootScope.getPaySum(data);
					}
				});
			};
			
		});
		//在初始化时拿到所有的支出类型
		$remote.post('queryType.do',{}, function(data) {
			$rootScope.types = data;
		});
		//在初始化时拿到所有的资金类型
		$remote.post('queryFund.do',{}, function(data) {
			$rootScope.funds = data;
		});
	}

	//模糊查找账单
	$scope.dimSearch = function() {
		var keyWords = $scope.keyWords;
		if("" == keyWords || null == keyWords) {
			alert("请输入查询内容！")
		} else {
			$remote.post('dimSearch.do', {
				'word': $scope.keyWords
			}, function(data) {
				$rootScope.datas = data;
				$scope.getPaySum(data);
			});
		};
	};
	//删除账单信息
	$scope.delete = function(id, url) {
		window.event ? window.event.cancelBubble = true : e.stopPropagation();
		var modalInstance = $modal.open({
			//弹出框中的页面URL
			templateUrl: url,
			//该页面的控制器
			controller: deleteModalInstanceCtrl
		});
		//控制器注入
		deleteModalInstanceCtrl.$inject = ['$scope', '$modalInstance'];

		function deleteModalInstanceCtrl($scope, $modalInstance) {
			//分别点击确定			
			$scope.ok = function() {
				$remote.post('delete.do', {
					'id': id
				}, function(data) {
					//重新获取数据
					$remote.post('findAll.do', {
						'bid': $rootScope.bid
					}, function(data) {
						$rootScope.datas = data;
						$scope.getPaySum(data);
					});
				});

				$modalInstance.close();
			};
			$scope.cancel = function() {
				$modalInstance.close();
			};
		};
	};

	//修改账单信息
	$scope.edit = function(item, url) {
		window.event ? window.event.cancelBubble = true : e.stopPropagation();
		var modalInstance = $modal.open({
			templateUrl: url,
			controller: updateModalInstanceCtrl
		});

		updateModalInstanceCtrl.$inject = ['$scope', '$modalInstance'];

		function updateModalInstanceCtrl($scope, $modalInstance) {
			//将该用户得信息带入到修改页面中
			$scope.pay = item.pay;
			$scope.date = item.date;
			$scope.note = item.note;
//			var typea;
//			$remote.post('queryTypeByTid.do', {'tid':item.tid}, function(data){
//				var type = data[0].type;
//				console.log(data[0].type);
//			});
			$scope.tid = item.tid;
			
			$scope.update = function() {
				if($scope.pay == null || $scope.date == null) {} else {
					var param = {
						"cid": item.cid,
						"pay": $scope.pay,
						"date": $scope.date,
						"note": $scope.note,
						"tid":$scope.tid
					}
					$remote.post('edit.do', param, function() {});
					//重新获取数据并关闭弹出框
					$remote.post('findAll.do', {
						'bid': $rootScope.bid
					}, function(data) {
						$rootScope.datas = data;
						$scope.getPaySum(data);
						$modalInstance.close();
					});
				};
			};
			$scope.cancel = function() {
				$modalInstance.close();
			};
		};
	}
	//新增账单
	$scope.add = function(url) {
		if($rootScope.bid == null) {
			alert("请您先添加一个账本吧~~");
		} else {
			window.event ? window.event.cancelBubble = true : e.stopPropagation();
			var modalInstance = $modal.open({
				templateUrl: url,
				size: "lg",
				controller: addModalInstanceCtrl
			});

			addModalInstanceCtrl.$inject = ['$scope', '$modalInstance'];

			function addModalInstanceCtrl($scope, $modalInstance) {
				$scope.ensure = function() {

					if($scope.pay == null || $scope.date == null || $scope.tid == null || $scope.fid == null) {
						alert("请填写完整信息哦~~");
					} else {
						var _date = $scope.date.toString().substring(0, 15);

						var param = {
							"pay": $scope.pay,
							"date": _date,
							"note": $scope.note,
							"tid": $scope.tid,
							"fid": $scope.fid,
							"bid": $rootScope.bid
						}
						$remote.post('add.do', param, function() {});
						//重新获取数据并关闭弹出框
						$remote.post('findAll.do', {
							'bid': $rootScope.bid
						}, function(data) {
							$rootScope.datas = data;
							$scope.getPaySum(data);
							$modalInstance.close();
						});
					};
				};
				$scope.cancel = function() {
					$modalInstance.close();
				};
			};
		}
	};

	//账本管理
	$scope.bookMang = function(url) {
		window.event ? window.event.cancelBubble = true : e.stopPropagation();
		var modalInstance = $modal.open({
			templateUrl: url,
			size: "lg",
			controller: bookMangModalInstanceCtrl
		});
		bookMangModalInstanceCtrl.$inject = ['$scope', '$modalInstance'];

		function bookMangModalInstanceCtrl($scope, $modalInstance) {
			//初始化该用户的账本
			$scope.init = function() {
				$scope.isEditShow = true;
				$scope.isAddShow = true;
				var uid = $scope.showInfo.uid;
				$remote.post('queryBook.do', {
					'uid': uid
				}, function(data) {
					if(data[0] == null) {
						$scope.noDatas = true;
						$scope.isEditShow = false;
					} else {
						$scope.books = data;
					}
				});
			};
			//编辑账本
			$scope.editBook = function() {
				$scope.isDelShow = true;
				$scope.isYesShow = true;
				$scope.isAddShow = false;
			};
			//结束编辑账本
			$scope.editBookEnd = function() {
				$scope.isDelShow = false;
				$scope.isYesShow = false;
				$scope.isAddShow = true;
			};
			//删除账本
			$scope.delBook = function(bid, url) {
				window.event ? window.event.cancelBubble = true : e.stopPropagation();
				var modalInstance = $modal.open({
					templateUrl: url,
					size: "lg",
					controller: delBookModalInstanceCtrl
				});
				delBookModalInstanceCtrl.$inject = ['$scope', '$modalInstance'];

				function delBookModalInstanceCtrl($scope, $modalInstance) {
					$scope.ok = function() {
						$remote.post('delCountByBid.do', {
							'bid': bid
						}, function() {
							$remote.post('delBook.do', {
								'bid': bid
							}, function() {
								var uid = $scope.showInfo.uid;
								$remote.post('queryBook.do', {
									'uid': uid
								}, function(data) {
									$scope.books = data;
								});
								location.reload();
							});
						});
						$modalInstance.close();
					};
					$scope.cancel = function() {
						$modalInstance.close();
					};
				};
			};
			//选择账本
			$scope.choseThisBook = function(bid, bookName) {
				$rootScope.bid = bid;
				$rootScope.bookName = bookName;
				$remote.post('findAll.do', {
					'bid': bid
				}, function(data) {
					if(data.length == 0){
						alert("该账本还没有数据哦~~~ 快点击'添加'来记录你的第一笔吧!");
					}
						$rootScope.datas = data;
						$rootScope.getPaySum(data);
				});
				$modalInstance.close();
			};
			//关闭
			$scope.cancel = function() {
				$modalInstance.close();
			};

			//添加账本
			$scope.addBook = function(url) {
				$scope.isNewBook = true;
				$scope.noDatas = false;
				$scope.isEditShow = false;
				$scope.insertNewBook = function() {
					var bookName = $('#bookName').val();
					if(bookName == "") {
						alert("必须输入账本名称哦~")
					} else {
						var uid = $scope.showInfo.uid;
						var param = {
							'uid': uid,
							'bookName': bookName
						}
						$remote.post('addBook.do', param, function() {
							$remote.post('queryBook.do', {
								'uid': uid
							}, function(data) {
								$scope.books = data;
								$scope.isNewBook = false;
								$scope.isEditShow = true;
							});
						});
					};

				};
			};

		};
	}
	
	$scope.manage = function(){
		var vis = $(".isShow").css('visibility');
		if('hidden'== vis){
			$(".isShow").css("visibility","visible");
			$(".isNotShow").css("visibility","hidden");
		}else{
			$(".isShow").css("visibility","hidden");
			$(".isNotShow").css("visibility","visible");
		};
	};
	

}