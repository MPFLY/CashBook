myCtrl.$inject = ['$scope', '$remote', "$timeout", "$filter", '$modal', "$rootScope"];

function myCtrl($scope, $remote, $timeout, $filter, $modal, $rootScope) {
	$rootScope.flag = 4;
	$rootScope.showBottom = true;
	//退出登录
	$scope.exit = function(url) {
		window.event ? window.event.cancelBubble = true : e.stopPropagation();
		var modalInstance = $modal.open({
			templateUrl: url,
			controller: exitModalInstanceCtrl
		});
		exitModalInstanceCtrl.$inject = ['$scope', '$modalInstance'];

		function exitModalInstanceCtrl($scope, $modalInstance) {
			$scope.ok = function() {
				sessionStorage.clear();
				location.reload();
			};
			$scope.cancel = function() {
				$modalInstance.close();
			};
		};
	};

	//	个人中心
	$scope.personal = function(url) {
		window.event ? window.event.cancelBubble = true : e.stopPropagation();
		var modalInstance = $modal.open({
			templateUrl: url,
			size: "lg",
			controller: personalModalInstanceCtrl
		});
		personalModalInstanceCtrl.$inject = ['$scope', '$modalInstance'];

		function personalModalInstanceCtrl($scope, $modalInstance) {
			$scope.update = function() {
				$("input").attr("disabled", false);
			};

			$scope.ensure = function() {
				var param = {
					"uid": $scope.showInfo.uid,
					"username": $scope.showInfo.uname,
					"password": $scope.showInfo.password,
				}
				$remote.post('updateById.do', param, function() {
					$modalInstance.close();
				});
				sessionStorage.setItem('userinfo', JSON.stringify(param));
				location.reload();
			};
			$scope.cancel = function() {
				$modalInstance.close();
			};
		};

	};
	var mySwiper = new Swiper('.swiper-container', {
		centeredSlides: true,
	  	loop: true,
		slidesPerView: '1',
		effect: 'slide',
		initialSlide: 0,
		observer: true,
//		zoom:true,
		
		autoplay: 3000,
		autoplayDisableOnInteraction : false,
		
		pagination: '.swiper-pagination',
		paginationType : 'progress',
		
		nextButton: '.swiper-button-next',
		prevButton: '.swiper-button-prev',
	});
};